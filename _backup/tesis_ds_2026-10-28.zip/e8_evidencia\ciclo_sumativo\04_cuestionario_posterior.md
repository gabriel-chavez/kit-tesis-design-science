# Cuestionario posterior (participante)

> Se completa al terminar la sesión, sin ayuda del autor. Escala 1 (muy bajo) a 5 (muy alto).

## Datos

| Campo | Valor |
|:--|:--|
| Participante (seudónimo) | |
| Caso asignado | |
| Fecha | |

## Claridad

| # | Afirmación | 1 | 2 | 3 | 4 | 5 |
|:--|:--|:--|:--|:--|:--|:--|
| 1 | El método se entiende sin explicaciones adicionales | | | | | |
| 2 | Los pasos y las reglas de decisión son claros | | | | | |
| 3 | La terminología (estados, saltos, compensación) es inequívoca | | | | | |
| 4 | Sabría aplicar el método a otro caso similar | | | | | |

## Esfuerzo

| # | Afirmación | 1 | 2 | 3 | 4 | 5 |
|:--|:--|:--|:--|:--|:--|:--|
| 5 | El esfuerzo para aplicar el método fue razonable | | | | | |
| 6 | El método evita tener que improvisar decisiones | | | | | |

## Confianza

| # | Afirmación | 1 | 2 | 3 | 4 | 5 |
|:--|:--|:--|:--|:--|:--|:--|
| 7 | Confío en que el método evita duplicados | | | | | |
| 8 | Confío en que deja un estado final consistente | | | | | |
| 9 | Recomendaría el método a otro equipo | | | | | |

## Preguntas abiertas

1. ¿Qué parte del método le resultó más ambigua o difícil? ¿Por qué?
2. ¿Qué parte le pareció innecesaria o redundante?
3. ¿Qué cambiaría para que sea más fácil de aplicar?
4. ¿Hubo algún momento en que el método no cubriera una situación del caso?
