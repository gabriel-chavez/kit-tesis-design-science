# Guion por escenario (participante)

> El participante recibe el método congelado (`ec9b8b6…`) y un caso nuevo. **No recibe ayuda del autor.**
> El observador registra en `03_hoja_observacion.md`.

## Instrucciones al participante

1. Lea el método y el caso asignado.
2. Ejecute el método paso a paso.
3. Si algo es ambiguo, diga qué asume y por qué (no pregunte al autor).
4. Al terminar, complete el cuestionario posterior.

## Escenarios (los seis de E6, mismos que la línea base)

| # | Escenario | Tarea del participante | Criterio de éxito |
|:--|:--|:--|:--|
| 1 | Caída de un servicio a mitad de la transacción | Decidir si reprocesar | No duplica; decisión correcta |
| 2 | Superación del tiempo de espera | Verificar el estado antes de decidir | Consulta y no duplica |
| 3 | Pérdida de respuesta | Distinguir procesado de no procesado | Estado correcto; sin duplicado |
| 4 | Solicitud duplicada | Evitar la segunda ejecución | Un solo recurso |
| 5 | Reintento tras éxito real | No repetir | Un solo recurso |
| 6 | Fallo al repetir una anulación | Compensar de forma idempotente | Una sola compensación |

## Por cada escenario, el observador anota

- Decisión tomada (reprocesar / compensar / reconciliar / confirmar).
- ¿Fue correcta a la primera? (sí / no)
- Error observado y su tipo.
- Tiempo hasta la decisión.
- ¿Pidió ayuda o consultó al autor? (sí / no)
- Ambigüedad declarada por el participante.
- Compensaciones efectivas en el externo y estado final (de la telemetría/contadores).

## Regla

Un escenario "aprobado" exige **criterio de utilidad cumplido** y **decisión correcta sin ayuda**. Aprobar por casualidad no cuenta: el observador registra el razonamiento.
