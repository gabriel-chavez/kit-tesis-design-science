# Hoja de observación (por participante)

## Datos de la sesión

| Campo | Valor |
|:--|:--|
| Participante (seudónimo) | |
| Perfil (rol, experiencia) | |
| ¿Independiente del autor? | Sí / No |
| Caso asignado | |
| Fecha y hora | |
| Observador (independiente) | |
| Versión evaluada (SHA-256) | `ec9b8b6…` |
| Doble / entorno | `busa-eval-stub` neutro |

## Registro por escenario

| # | Escenario | Decisión del participante | ¿Correcta a la primera? | Error observado | Tiempo (min) | ¿Pidió ayuda? | Ambigüedad declarada | Compensaciones efectivas | Estado final bitácora | Estado final externo | ¿Criterio de utilidad cumplido? |
|:--|:--|:--|:--|:--|:--|:--|:--|:--|:--|:--|:--|
| 1 | Caída a mitad | | | | | | | | | | |
| 2 | Timeout | | | | | | | | | | |
| 3 | Pérdida de respuesta | | | | | | | | | | |
| 4 | Duplicada | | | | | | | | | | |
| 5 | Reintento tras éxito | | | | | | | | | | |
| 6 | Fallo al repetir anulación | | | | | | | | | | |

## Control negativo de la sesión

| Condición | Compensaciones efectivas | ¿Duplica? |
|:--|:--|:--|
| Sin K5 | | |
| Con K5 | | |

**Si sin K5 no duplica, el doble no es neutro: la sesión se invalida.**

## Resumen de la sesión

| Métrica | Valor |
|:--|:--|
| Tareas sin ayuda | / 6 |
| Puntos críticos a la primera | / 2 |
| Tiempo total | |
| Ambigüedades | |
| ¿Sesión válida? | Sí / No |
