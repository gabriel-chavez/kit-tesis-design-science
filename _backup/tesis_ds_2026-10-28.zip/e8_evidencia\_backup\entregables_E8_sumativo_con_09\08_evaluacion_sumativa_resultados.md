# E8 - Resultados de la evaluación sumativa (medición técnica)

**Fecha de ejecución:** 2026-10-28  
**Artefacto:** `E7e_MetodoCompensacion` (netstandard2.0)  
**SHA-256 verificado:** `ec9b8b6e8d37374ff28f2eb816285571ede997c47ec44a235da829d13dbd10bf`  
**Doble de evaluación:** `busa-eval-stub`, neutro, `localhost:5098`  
**Entorno:** aislado, datos sintéticos, sin BUSA real ni base de producción.  

> **Declaración metodológica estricta:** Este documento reporta con exclusividad la **medición técnica**. Las sesiones humanas con los participantes P1 (Leonel Chamaca Lima) y P2 (Ernesto Arce) no se han ejecutado en esta estación y se declaran formalmente como **pendientes**. Como asistente de investigación técnico, no se sustituye al observador independiente ni a los practicantes, garantizando que ningún dato humano sea inventado.

---

## 1. Diseño de la Corrida Técnica

- **Condición A (Método congelado):** Artefacto K1–K9 ejecutado sobre el doble neutro.
- **Condición B (Línea base / Conducta actual):** Reintentos con espera fija (150 ms para no penalizar la corrida; real 1 s), sin verificación de estado ni mecanismo de idempotencia, re-ejecutados sobre el **mismo doble neutro**.
- **Casos de prueba fijos:**
  - `CASO-A` (`63442 / 4`): 2 filas `ANULADO`, importe 200,00, fecha 2026-01-23. Duplicado histórico de la misma llave lógica; prueba la unicidad y condición **Dc10**.
  - `CASO-B` (`1598416 / 1`): 1 fila `ANULADO`, importe 196,00, fecha 2025-12-31. Control limpio sin duplicado.
  - *Excluido:* `10565 / 4` por tener fila `PAGADO` (violación de **Dc8**, no reversión de pagos).
- **Control negativo de corrida:** Ejecutado en cada condición de compensación. Sin K5 debe duplicar; con K5 debe producir exactamente 1 efecto.
- **Integridad del artefacto:** Hash SHA-256 verificado antes y después de la corrida.

---

## 2. Resultados: Método Congelado

| Caso | Escenario | Recursos creados | Compensaciones | Estado bitácora | Estado externo | Decisión K4 | Llamadas ext. | Consultas K3 | Latencia (ms) | Inconsistente | Cumple criterio |
|---|---|:---:|:---:|---|---|---|:---:|:---:|:---:|:---:|:---:|
| A | E1 Caída a mitad | 0 | 0 | NoProcesada | SOLICITADO | Reprocesar | 1 | 1 | 31 | 0 | **Sí** |
| A | E2 Timeout | 1 | 0 | Procesada | SOLICITADO | ConfirmarProcesada | 1 | 1 | 2015 | 0 | **Sí** |
| A | E3 Respuesta perdida | 1 | 0 | Procesada | SOLICITADO | ConfirmarProcesada | 1 | 1 | 2 | 0 | **Sí** |
| A | E4 Solicitud duplicada | 1 | 0 | Procesada | SOLICITADO | ConfirmarProcesada | 1 | 0 | 1 | 0 | **Sí** |
| A | E5 Reintento tras éxito | 1 | 0 | Procesada | SOLICITADO | ConfirmarProcesada | 1 | 0 | 0 | 0 | **Sí** |
| A | E6 Fallo al repetir anulación | 1 | 1 | Compensada | ANULADO | Compensar | 2 | 0 | 5 | 0 | **Sí** |
| B | E1 Caída a mitad | 0 | 0 | NoProcesada | SOLICITADO | Reprocesar | 1 | 1 | 2 | 0 | **Sí** |
| B | E2 Timeout | 1 | 0 | Procesada | SOLICITADO | ConfirmarProcesada | 1 | 1 | 2014 | 0 | **Sí** |
| B | E3 Respuesta perdida | 1 | 0 | Procesada | SOLICITADO | ConfirmarProcesada | 1 | 1 | 2 | 0 | **Sí** |
| B | E4 Solicitud duplicada | 1 | 0 | Procesada | SOLICITADO | ConfirmarProcesada | 1 | 0 | 0 | 0 | **Sí** |
| B | E5 Reintento tras éxito | 1 | 0 | Procesada | SOLICITADO | ConfirmarProcesada | 1 | 0 | 1 | 0 | **Sí** |
| B | E6 Fallo al repetir anulación | 1 | 1 | Compensada | ANULADO | Compensar | 2 | 0 | 2 | 0 | **Sí** |

- **Efectividad técnica:** 12/12 combinaciones escenario-caso cumplen los criterios de utilidad congelados.
- **Deduplicación:** 0 recursos duplicados; 0 compensaciones duplicadas; 0 estados inconsistentes.

---

## 3. Resultados: Línea Base (Conducta Actual re-ejecutada sobre doble neutro)

| Caso | Escenario | Recursos creados | Compensaciones | Estado registrado | Estado externo | Decisión | Llamadas ext. | Consultas K3 | Latencia (ms) | Inconsistente | Cumple criterio |
|---|---|:---:|:---:|---|---|---|:---:|:---:|:---:|:---:|:---:|
| A | E1 Caída a mitad | 0 | 0 | Error | SOLICITADO | Sin K4 | 5 | 0 | 785 | 0 | **No** |
| A | E2 Timeout | 2 | 0 | Procesada | SOLICITADO | Sin K4 | 2 | 0 | 2167 | 0 | **No** |
| A | E3 Respuesta perdida | 2 | 0 | Procesada | SOLICITADO | Sin K4 | 2 | 0 | 160 | 0 | **No** |
| A | E4 Solicitud duplicada | 3 | 0 | Procesada | SOLICITADO | Sin K4 | 3 | 0 | 1 | 0 | **No** |
| A | E5 Reintento tras éxito | 2 | 0 | Procesada | SOLICITADO | Sin K4 | 2 | 0 | 1 | 0 | **No** |
| A | E6 Fallo al repetir anulación | 1 | 4 | Compensada | ANULADO | Sin K4 | 5 | 0 | 160 | 0 | **No** |
| B | E1 Caída a mitad | 0 | 0 | Error | SOLICITADO | Sin K4 | 5 | 0 | 780 | 0 | **No** |
| B | E2 Timeout | 2 | 0 | Procesada | SOLICITADO | Sin K4 | 2 | 0 | 2163 | 0 | **No** |
| B | E3 Respuesta perdida | 2 | 0 | Procesada | SOLICITADO | Sin K4 | 2 | 0 | 154 | 0 | **No** |
| B | E4 Solicitud duplicada | 3 | 0 | Procesada | SOLICITADO | Sin K4 | 3 | 0 | 1 | 0 | **No** |
| B | E5 Reintento tras éxito | 2 | 0 | Procesada | SOLICITADO | Sin K4 | 2 | 0 | 1 | 0 | **No** |
| B | E6 Fallo al repetir anulación | 1 | 4 | Compensada | ANULADO | Sin K4 | 5 | 0 | 158 | 0 | **No** |

- **Efectividad técnica:** 0/12 combinaciones cumplen.
- **Fallas observadas:** Duplicación sistemática de recursos (E2 a E5), sobre-compensación cuádruple en E6 (4 anulaciones ejecutadas) y agotamiento de reintentos en E1 sin resolución convergente.

---

## 4. Comparación Técnica: Método vs. Línea Base

| Métrica | Método congelado | Línea base | Diferencia | Impacto técnico |
|---|:---:|:---:|:---:|---|
| **Escenarios-caso cumplidos** | **12 / 12** | 0 / 12 | **+12** | Aislamiento completo de fallos |
| **Recursos duplicados totales** | **0** | 10 | **−10** | Eliminación de cobros/QRs dobles |
| **Compensaciones duplicadas** | **0** | 6 | **−6** | Prevención de anulaciones redundantes |
| **Estados inconsistentes** | **0** | 0 | 0 | Ambos convergen a estados terminales |
| **Consultas de estado (K3)** | 6 | 0 | +6 | Sobrecarga deliberada para verificar |
| **Llamadas externas totales** | **14** | 38 | **−24** | Disminución del 63% en tráfico externo |

---

## 5. Control Negativo de Corrida

| Caso | Invocaciones | Sin K5 (control negativo) | Con K5 (método) | Estado del control |
|---|:---:|:---:|:---:|:---:|
| `CASO-A` (`63442 / 4`) | 3 | **3 efectos** (duplica) | **1 efecto** (idempotente) | **CONFIRMADO** |
| `CASO-B` (`1598416 / 1`) | 3 | **3 efectos** (duplica) | **1 efecto** (idempotente) | **CONFIRMADO** |

> **Validez del entorno:** El control negativo demuestra que el doble de evaluación no tiene lógica de deduplicación interna. La propiedad de idempotencia observada es aportada única y exclusivamente por el componente K5 del método.

---

## 6. Estado de las Sesiones Humanas

| Participante | Caso | Guion escenarios | Hoja observación | Cuestionario | Entrevista | Estado |
|---|---|:---:|:---:|:---:|:---:|:---:|
| **P1** (Leonel Chamaca) | `CASO-A` | Listo | En blanco | En blanco | En blanco | **Pendiente** |
| **P2** (Ernesto Arce) | `CASO-B` | Listo | En blanco | En blanco | En blanco | **Pendiente** |

---

## 7. Alcance y Límites de la Evidencia

La evidencia técnica demuestra la idempotencia y la consistencia en **una instancia de proceso**. No demuestra idempotencia distribuida en un cluster de servidores múltiples. La garantía en sistemas distribuidos concurrentes depende estrictamente del despliegue del índice único en base de datos (**Dc10**), el cual permanece catalogado como condición de despliegue.
