# Mapeo de identidad K1

## Definición adoptada

La llave lógica de la operación es:

> `(TRAMITE_SECUENCIAL, T_PAR_SIMPLE_TRAMITE_FK)`

**No se usa `GESTION` como año.** El segundo componente es el trámite/canal (`T_PAR_SIMPLE_TRAMITE_FK`), no la gestión anual.

## Correspondencia con K1

El código de K1 recibe dos parámetros:

```csharp
DerivarLlave(long tramiteNumero, int gestion)
```

En esta evaluación se mapean así:

| Parámetro K1 | Columna real | CASO-A | CASO-B |
|---|---|---|---|
| `tramiteNumero` | `TRAMITE_SECUENCIAL` | 63442 | 1598416 |
| `gestion` | `T_PAR_SIMPLE_TRAMITE_FK` | 4 | 1 |
| Llave resultante | `TRAMITE_SECUENCIAL \| T_PAR_SIMPLE_TRAMITE_FK` | `63442\|4` | `1598416\|1` |

## Consecuencia

- La identidad es reproducible en la cadena y sobrevive a los reintentos.
- Si en algún documento de la tesis se describe `GESTION` como año, debe corregirse o declararse la diferencia. El código congelado no se modifica; el mapeo se documenta aquí.
- La llave no incluye datos personales.

## Verificación

El SHA-256 del artefacto evaluado es:

`ec9b8b6e8d37374ff28f2eb816285571ede997c47ec44a235da829d13dbd10bf`

No se modificó el artefacto para esta evaluación.
