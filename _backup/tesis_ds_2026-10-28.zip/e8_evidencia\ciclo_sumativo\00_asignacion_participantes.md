# Asignación definitiva de participantes — Ciclo sumativo

> **Muestra: n = 2.** Versión congelada: `ec9b8b6…` (no se modifica).

## 1. Participantes y casos

| Código | Participante | ¿Del walkthrough? | Caso | Llave operativa |
|:--|:--|:--|:--|:--|
| P1 | Leonel Chamaca Lima | Sí | `CASO-A` — duplicado real | `63442 / 4` |
| P2 | Ernesto Gutierrez | **No** (nuevo) | `CASO-B` — limpio (control) | `1598416 / 1` |

**Cumple:** casos distintos; ninguno es `3147/2026` en ambos; al menos uno (P2) es nuevo; P1 no queda como único evaluador.

## 2. Detalle de los casos

| Campo | `CASO-A` | `CASO-B` |
|:--|:--|:--|
| `TRAMITE_SECUENCIAL` | 63442 | 1598416 |
| `T_PAR_SIMPLE_TRAMITE_FK` | 4 (SOAT - POS) | 1 (SOAT - APP Móvil) |
| Filas | **2**, ambas `ANULADO` | 1, `ANULADO` |
| Importe | 200,00 | 196,00 |
| Fecha | 2026-01-23 | 2025-12-31 |
| Uso | Duplicado histórico de la misma llave lógica; prueba unicidad y condición **Dc10** | Control sin duplicado; comparación contra `CASO-A` |

**Casos excluidos:** `10565/4` no se usa porque tiene una fila `PAGADO` y cruzaría la condición **Dc8** (no reversión de pagos). Los dos casos elegidos son `ANULADO`.

## 3. Orden aleatorizado de escenarios

Registrar antes de cada sesión. Ejemplo:

| Orden | P1 (Leonel) | P2 (Ernesto) |
|:--|:--|:--|
| 1.º | 3 — Pérdida de respuesta | 5 — Reintento tras éxito |
| 2.º | 1 — Caída a mitad | 4 — Duplicada |
| 3.º | 5 — Reintento tras éxito | 2 — Timeout |
| 4.º | 2 — Timeout | 6 — Fallo al repetir anulación |
| 5.º | 6 — Fallo al repetir anulación | 1 — Caída a mitad |
| 6.º | 4 — Duplicada | 3 — Pérdida de respuesta |

## 4. Checklist de sesión

- [ ] Versión congelada `ec9b8b6…`.
- [ ] Caso asignado y registrado.
- [ ] Observador independiente (no el autor).
- [ ] Telemetría y contadores del doble activos.
- [ ] Control negativo ejecutado (sin K5 duplica; con K5 no).
- [ ] Hoja de observación + cuestionario + entrevista.

> Si el control negativo no duplica sin K5, la sesión se invalida.

## 5. Mapeo resuelto

Se adoptó la **Opción A**: la llave operativa es `(TRAMITE_SECUENCIAL, T_PAR_SIMPLE_TRAMITE_FK)`; se elimina `GESTION` como año. Ver `08_mapeo_identidad_k1.md`.
