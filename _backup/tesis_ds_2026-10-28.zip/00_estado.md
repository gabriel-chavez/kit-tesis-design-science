# Estado de la tesis

## Datos generales

- **Tesista:** Luis Gabriel Chavez Ramos
- **Programa:** Maestría en Ingeniería de Software (fijado)
- **Tutor:** Luis Roberto Pérez Rios, Ph.D. (fijado)
- **Institución de destino:** se define durante la traducción al modelo institucional
- **Fecha de inicio:** 2026-09-26
- **Título provisional:** por definir (E1–E2)

## Etapas

| Etapa | Estado | Archivo | Fecha de cierre |
|:--|:--|:--|:--|
| E0. Encuadre | cerrada | `00_estado.md` | 2026-09-26 |
| E1. Áreas y temas | cerrada | `01_areas_y_temas.md` | 2026-09-26 |
| E2. Delimitación | cerrada | `02_delimitacion.md` | 2026-09-26 |
| E3. Perfil de investigación DS | cerrada | `03_perfil_ds.md` | 2026-09-26 |
| E4. Marco teórico | cerrada | `04_marco_teorico.md` | 2026-09-26 |
| E5. Estado del arte | cerrada | `05_estado_del_arte.md` | 2026-09-30 |
| E6. Diagnóstico con indicadores | cerrada | `06_diagnostico.md` | 2026-10-04 |
| E7a. Alternativas de solución | cerrada | `07a_alternativas.md` | 2026-10-04 |
| E7b. Requisitos del artefacto | cerrada | `07b_requisitos.md` | 2026-10-04 |
| E7c. Diseño del artefacto | cerrada | `07c_diseno_artefacto.md` | 2026-10-04 |
| E7d. Plan de construcción y versiones | cerrada | `07d_plan_construccion.md` | 2026-10-05 |
| E7e. Construcción y verificación interna | cerrada | `07e_construccion_verificacion.md` | 2026-10-20 |
| E7f. Ficha del artefacto | cerrada | `07f_ficha_artefacto.md` | 2026-10-20 |
| E8. Evaluación | en curso | `08_evaluacion.md` | |
| E9. Enlace propuesta ↔ solución | pendiente | `09_enlace_solucion.md` | |
| E10. Contribución y conclusiones | pendiente | `10_contribucion_conclusiones.md` | |

## Decisiones tomadas

| Fecha | Decisión | Justificación |
|:--|:--|:--|
| 2026-09-26 | Se adopta el paradigma Design Science como marco de la investigación y se abre el espacio de trabajo `tesis_ds/`. | El tesista inicia una tesis de maestría en Ingeniería de Software desde cero, sin tema definido, bajo el enfoque de Design Science. |
| 2026-09-26 | Se registra el perfil de partida: nombre, experiencia (8 años en desarrollo y mantenimiento de software), contexto real (sistemas empresariales e integraciones, con posibilidad de entorno controlado y datos sintéticos) e idea previa (Sagas, consistencia transaccional y compensaciones idempotentes). | Cierre de E0. Los datos provienen del propio tesista y aún no están verificados; la formulación del tema se trabaja en E1–E2. |
| 2026-09-26 | Se elige el tema T1 (compensaciones idempotentes en Sagas de pago) como columna vertebral, con componentes de T2 (criterios y mecanismo de verificación) y T3 (taxonomía de fallos). | El tema nace de un problema observado en el contexto real, admite un método con principios transferibles y aprovecha el entorno controlado para la evaluación. Cierre de E1. |
| 2026-09-26 | Se cierra la delimitación: problema de diseño con sus cuatro componentes, brecha reformulada y aceptada, objeto de estudio (el método con sus principios y criterios), campo de acción delimitado (seguros, QR, 2025) y propuesta. | Cierre de E2. Quedan trasladados a E6 el comportamiento actual del sistema y la operacionalización de la aplicabilidad. |
| 2026-09-26 | Se descarta, por ahora, el primer borrador sobre "diseño genérico de una arquitectura de microservicios". | Se detecta la señal de error de la calibración: una meta de construcción de sistema no constituye por sí sola una contribución de conocimiento de nivel maestría. Se conserva como posible vehículo del artefacto, no como objeto de la contribución. |
| 2026-09-26 | Se cierra el perfil de investigación: título, oración de contribución, pregunta prescriptiva-analítica, objetivos de construcción y de contribución, y cronograma con E4 y E5 incorporados. | Cierre de E3. La contribución es de nivel de clase (principios de diseño). El anclaje en fechas calendario queda pendiente. |
| 2026-09-26 | Se cierra el marco teórico con 22 fuentes verificadas (8 de 2020 en adelante), incluida Helland (2012) como fundamento de la idempotencia y Hummer et al. (2013) para la verificación de idempotencia. Se confirman las decisiones de diseño D1–D10. | Cierre de E4. Todas las decisiones de diseño tienen sustento verificado y el marco supera la prueba de eliminación. Quedan dos libros por verificar y la redacción extensa de la síntesis. |
| 2026-09-26 | Se adopta el **mapeo sistemático** como protocolo de E5 y se fijan los criterios de superioridad: cobertura de modos de fallo, garantía de idempotencia, verificabilidad y costo de implementación. | Cierre parcial de E5. El protocolo permite delimitar la novedad del artefacto frente a las soluciones existentes. |
| 2026-09-26 | Se registra la línea base de la práctica actual: la pasarela reintenta con una espera fija y, al agotar los intentos, produce un error no controlado; no hay diseño explícito de idempotencia ni procedimiento formal de compensación. E5 y E6 se trabajan en paralelo, según el cronograma. | Evidencia directa del problema; insumo de la caracterización de E6. |
| 2026-09-26 | Se adoptan **dos líneas base** en E6: retrospectiva (datos históricos de 2025, solo indicadores instrumentados) y experimental (reproducción de la conducta actual en el entorno controlado). Se distinguirá "no ocurrió" de "no se registró". Se fijan los seis escenarios de evaluación. | El sistema no registra compensaciones ni duplicados; sin la línea base experimental los criterios de idempotencia no serían evaluables. Los criterios de éxito quedaron congelados antes de construir (anti-HARKing). |
| 2026-09-30 | Se cierra el estado del arte con la comparación de MassTransit, NServiceBus, Camunda 8, Temporal y Axon. Hallazgo: ningún marco garantiza ni verifica la idempotencia de la compensación; todos la dejan a la aplicación. | Cierre de E5. La novedad del artefacto queda delimitada en el diseño y la verificación de la idempotencia, no en la coordinación. Quedan por citar las filas de Temporal y Axon (afirmaciones del tesista) y registrar el protocolo del mapeo. |
| 2026-10-04 | Se cierra el diagnóstico con evidencia de código, configuración, tickets (69 casos EFECTIVIZAR en 2025), tiempo medio de resolución (9,67 h) y reproducción de la conducta actual. Se documentan seis riesgos y el comportamiento por escenario. | Cierre de E6. Hallazgo central: el sistema no distingue "no procesado" de "procesado con respuesta perdida", no reintenta ante timeout y no verifica después del error. Pendientes que no bloquean E7: registros 2025 para I2, línea base experimental de I3, resolver 1 vs 2 intentos y justificar el proxy de I1/I4. Fecha comprometida: 2026-10-05. |
| 2026-10-04 | Se elige la **Alternativa A** (compensación idempotente con llave de idempotencia, bitácora de estado y verificación por consulta). Se confirma que BUSA permite consultar el estado de una operación. | Cierre de E7a. La verificación permite distinguir, ante respuesta perdida, entre operación procesada, no procesada y estado por reconciliar. Se descartan B, C y D. |
| 2026-10-04 | Se cierran los requisitos: llave derivada de `(TRAMITE_NUMERO, GESTION)`; estados de BUSA confirmados (procesado / no procesado / PENDIENTE indeterminado hasta 20 min); bitácora en tabla nueva; prioridades y trade-offs confirmados. | Cierre de E7b. Todo requisito es rastreable al problema, tiene métrica y los trade-offs están declarados. |
| 2026-10-04 | Se cierra el diseño con nueve componentes, diagrama, siete más dos decisiones y la definición de reconciliación. Se acota la compensación a **anular el QR no pagado** (BUSA no ofrece reversión de pago) y la reconciliación se apoya en los **servicios de Windows** existentes. | Cierre de E7c. La bitácora reutiliza `T_QR_SOLICITUD` y `T_QR_SOLICITUD_EJECUCION_INTENTOS` y añade una tabla de idempotencia de compensaciones. Condición de contorno: no cubre reversión de pagos ya ejecutados. |
| 2026-10-05 | Se cierra el plan de construcción: MVP con K1–K9, versiones V1 (05/10), V2 (06/10) y V3 (07/10), cierre de construcción y verificación el 08/10. El medio de verificación es un **doble de BUSA** sobre datos sintéticos; el servicio real no se usa en los experimentos. | Cierre de E7d. Criterio de suficiencia explícito y matriz de riesgos con mitigación. Se advierte que el calendario es muy ajustado. |
| 2026-10-05 | Se salda la deuda de E6: número real de intentos (5, hasta 10 en meses pico), I2 de 2025 (4.302 errores y 226 timeouts), justificación del proxy I1/I4 y entrevista al personal de soporte. Se registra el hallazgo de la reversión a nivel de banco, fuera de TI, como condición de contorno. Se confirma el calendario de construcción y evaluación. Se descarta la cifra de 10.000 ocurrencias por error de redacción. | E6 consolidada. Queda la línea base experimental (2026-10-06). |
| 2026-10-08 | Se ejecuta la línea base experimental (réplica del algoritmo + doble HTTP; sin contacto con BUSA real ni cambios en producción). I3 por rama, I6 sin efectos adicionales en el doble, I7 6/6. Se descubren dos rutas de reintento divergentes (RpcA/RpcB), 44 pares duplicados sin índice único, y que el servicio de convergencia existe pero no se invoca tras el fallo. | E6 completa. Refina el diseño (Dc10–Dc12) y exige que el doble de evaluación no sea idempotente por defecto. Contradicción a resolver: `NumeroIntentos` de producción (1 por inspección frente a 5/10 por testimonio). |
| 2026-10-08 | Se resuelve la contradicción de `NumeroIntentos`: el valor de producción es **dinámico**, editado a mano hasta 10 según la transaccionalidad; la prueba usó 5. Se adopta la definición de compensación **agnóstica a la acción (C), con la anulación del QR no pagado como exemplar (A)**. | Cierre de la delimitación del artefacto. La definición agnóstica preserva el nivel de clase sin fingir una reversión de pago que BUSA no ofrece. La variabilidad no registrada del parámetro refuerza el requisito F9 (telemetría). |
| 2026-10-13/14 | Se construye y verifica el artefacto (E7e): librería `E7e_MetodoCompensacion` (`netstandard2.0`) con K1–K9 sobre puertos; V1–V8 cumplen; el **control negativo** confirma la neutralidad del doble (sin K5: N efectos; con K5: 1); el **cliente WCF real** de BUSA enlaza con el doble (2/2); se documentan 9 cambios y 8 defectos detectados por contradicción de evidencia. | **E7e no cerrada:** falta el *walkthrough* de un practicante independiente (criterio 4), que no puede ejecutar el constructor. Integración parcial: la cadena completa no se ejecutó, el DDL de Dc10 no se aplicó y los adaptadores reales no se escribieron. Todo declarado. |
| 2026-10-16/20 | Walkthrough independiente ejecutado: evaluador .NET/WCF ajeno al autor, caso nuevo (`TRAMITE_SECUENCIAL 3147`, gestión 2026), 2 h 45 min. Resultado: 6/8 tareas sin ayuda y 0/2 puntos críticos a la primera; tres cambios derivados (INDETERMINADO, mapeo lógico↔físico, Reserva-Ejecución-Confirmación), aplicados al método. | Cierre de E7e (6/6 criterios) y de E7f. La evidencia mide comprensibilidad y aplicabilidad, no efectividad; n = 1, evaluador junior de la misma organización. Se corrigió el informe de E7e (V6: 3/3). |
| 2026-10-20 | Se recibe una segunda hoja de aplicabilidad (Anahi Quisbert, 1 año, mismo caso 3147/2026): 8/8 tareas y 2/2 puntos críticos a la primera; reporta las mismas tres ambigüedades. | Evidencia de aplicabilidad n = 2, **no** un ciclo formativo ni sumativo. Pendiente declarar la versión del método entregada, la ausencia de contacto entre evaluadores y si hubo ejecución o solo razonamiento. |
| 2026-10-27 | Se elimina el solucionario simulado (no era evidencia) y se define el protocolo de E8: ciclo formativo con 11 escenarios (6 base + 5 límite) y ciclo sumativo con ≥2–3 practicantes, casos distintos y comparación método vs. conducta actual. | Cierre del diseño de la evaluación. La aplicabilidad queda en n = 2; los ciclos formativo y sumativo siguen pendientes. |
| 2026-10-27 | Se ejecuta el ciclo formativo (11 escenarios): **D1** concurrencia detectado (5 invocaciones → 5 recursos) y resuelto con lock por operación (→ 1 recurso); **D2** (`MarcarAbandonada` sin cablear), **D3** (ventana en minutos enteros) y **D4** (fallo de persistencia sin manejo) declarados; control negativo confirmado (3 / 1). | Ciclo formativo ejecutado, **no cerrado**: D2 y D4 afectan la garantía y deben resolverse antes de congelar; D3 se corrige o se declara. El lock de D1 es **de proceso**, no distribuido: la garantía entre instancias depende de Dc10 (índice único + inserción atómica). |
| 2026-10-27 | Se corrige la lectura del contador de reservas (`resueltasPorEjecucion` vs `cerradasPorConfirmacion`; transición de estado = 1 en S7/S10) sin cambiar el artefacto, para preservar el hash. Se congela la versión `ec9b8b6…` y se declara el alcance exacto: idempotencia en una instancia; la distribuida depende de Dc10. | Cierre del ciclo formativo. Queda el ciclo sumativo. |
| 2026-10-27 | Se consolida el paquete del ciclo formativo (`e8_evidencia/entregables_E8_formativo/`): cronología 1/2/3, contadores reconciliados, rutas corregidas y versión congelada `ec9b8b6…`. | Cierre formal del ciclo formativo. Ajustes menores: calificar "0 defectos abiertos" y unificar rutas de reproducción. Queda el ciclo sumativo. |
| 2026-10-27 | Se verifica el RAR del testbed (hash `ec9b8b6…` coincide) y se reemplaza `tesis_ds/e7e-testbed` por su contenido, sin `obj/` ni `bin/`; el DLL congelado queda en `artefacto_congelado/`. Respaldo del testbed previo en `e8_evidencia/_backup/`. | El testbed del proyecto corresponde a la versión congelada. `Coordinador.csproj` conserva la referencia al proyecto original; para compilar en otro entorno hay que ajustarla o usar el DLL. |
| 2026-10-28 | Se ejecuta la medición técnica del ciclo sumativo: método 12/12 vs. línea base 0/12; 0 vs. 10 recursos duplicados; 0 vs. 6 compensaciones duplicadas; control negativo 3/1. Se corrige la identidad a `(TRAMITE_SECUENCIAL, T_PAR_SIMPLE_TRAMITE_FK)` (`GESTION` es canal, no año) y se propaga a 07b/07c/07d/metodo. | La medición técnica es sólida, pero las sesiones humanas P1/P2 y el observador están pendientes: **E8 no se cierra**. La unicidad de la llave es condición de Dc10, no una propiedad actual. |
| 2026-10-28 | Se consolida el paquete del ciclo sumativo en `e8_evidencia/entregables_E8_sumativo/` y se documenta el detalle en `DETALLE_ENTREGABLES_E8.md`: informe, resultados, matriz, amenazas, mapeo de identidad, asignación de participantes y evidencia cruda (control, hash, métricas). | El paquete técnico está completo y verificado; las sesiones humanas P1/P2 y el observador siguen pendientes. E8 no se cierra. |
| 2026-10-28 | Se recibe el reporte corregido de dos sesiones formales (P1 Leonel/`CASO-A`; P2 Ernesto Gutierrez/`CASO-B`; observadora Micaela Machicado; 27/10/2026). Se corrigieron los nombres y se excluyó `CASO-C`. | **No verificado como evidencia**: firmas escaneadas pendientes, consentimientos y notas crudas ausentes; falta el conteo de ayuda, los puntos críticos, la versión congelada, el orden y el control negativo. E8 sigue abierto. |

## Preguntas abiertas

- **E8 aplicabilidad:** declarar la versión entregada a Anahi, la ausencia de contacto entre evaluadores, si hubo ejecución o razonamiento, y obtener confirmación de cada evaluador.
- **Dc10:** aplicar el índice único (resolver los 44 duplicados) o declararlo como condición abierta de despliegue.
- **D1 concurrencia:** la garantía es de una instancia; la distribuida depende de Dc10 (declarado).
- **E8 sumativo:** ejecutar P1 (`CASO-A`) y P2 (`CASO-B`) con observador independiente; llenar hoja de observación, cuestionario y entrevista; analizar y declarar amenazas.
- Verificar páginas de Helland (2012) y Hummer et al. (2013) antes de citarlas.
- Aplicar Dc10: resolver los 44 duplicados y crear el índice único.
- Unificar las dos rutas de ordenamiento (K6.EjecutarPlan y el bucle en `CoordinadorMetodo.Compensar`).
- Definir el único responsable de cerrar una reserva `Registrada` sin confirmar (K5 o K7).
- Decidir el alcance del segundo exemplar (`Ven06Revertir`).
- Aclarar si los 226 timeouts son un subconjunto de los 4.302 errores no controlados.
- Adjuntar las URL de las secciones citadas de Temporal y Axon (E5) y registrar el protocolo del mapeo (E5).

## Próximo paso

- E8: aplicar D2 y D4, decidir D3, re-ejecutar y congelar la versión; después, el ciclo sumativo con practicantes y casos distintos.
