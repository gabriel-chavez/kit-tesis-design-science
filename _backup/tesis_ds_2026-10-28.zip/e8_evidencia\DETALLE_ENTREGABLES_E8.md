# Detalle de los entregables del ciclo sumativo (E8)

**Versión evaluada:** `E7e_MetodoCompensacion` (netstandard2.0)
**SHA-256:** `ec9b8b6e8d37374ff28f2eb816285571ede997c47ec44a235da829d13dbd10bf`
**Fecha:** 2026-10-28
**Ubicación:** `tesis_ds/e8_evidencia/entregables_E8_sumativo/`

## 1. Documentos

| # | Archivo | Rol en la tesis | Contenido y aporte | Estado |
|:--|:--|:--|:--|:--|
| 1 | `informe_ciclo_sumativo.md` | Informe principal de evaluación | Diseño experimental, comparación 12/12 vs. 0/12, análisis de causalidad, control negativo y declaración de alcance | Completo en lo técnico; sesiones humanas pendientes |
| 2 | `08_evaluacion_sumativa_resultados.md` | Reporte técnico de resultados | Corrida por escenario y caso (`CASO-A` 63442/4; `CASO-B` 1598416/1), telemetría K3, contadores del doble y control negativo | Completo |
| 3 | `matriz_analisis.md` | Matriz consolidada | Conteos exactos escenario × caso, balance método vs. línea base y matriz de participantes (pendiente) | Parcial: la parte humana está en blanco |
| 4 | `amenazas_validez.md` | Rigor metodológico (DSR) | Amenazas de constructo, interna, externa y de conclusión, con mitigación e impacto residual | Completo |
| 5 | `08_mapeo_identidad_k1.md` | Corrección de la llave de identidad | `GESTION` no es el año: es el canal (`T_PAR_SIMPLE_TRAMITE_FK`). Llave: `(TRAMITE_SECUENCIAL, T_PAR_SIMPLE_TRAMITE_FK)` | Completo; propagado a `07b`, `07c`, `07d` y `metodo.md` |
| 6 | `00_asignacion_participantes.md` | Muestra y casos | P1 = `CASO-A` (duplicado histórico); P2 = `CASO-B` (control); n = 2; orden aleatorizado y checklist | Diseño completo; sesiones pendientes |

## 2. Evidencia cruda (`evidencia_sumativo/`)

| Archivo | Contenido | Estado |
|:--|:--|:--|
| `control_negativo_sumativo.md` | Sin K5 = 3 efectos; con K5 = 1, en ambos casos | Confirmado |
| `hash_verificacion.txt` | SHA-256 `ec9b8b6…`, verificado el 2026-10-28 | Confirmado |
| `metodo_crudo.md` | Salida cruda de la corrida del método | Completo |
| `linea_base_crudo.md` | Salida cruda de la línea base | Completo |
| `metricas.csv` | 24 filas: 12 método + 12 línea base | Completo |

## 3. Qué está demostrado y qué no

**Demostrado (técnico):**
- 12/12 escenarios-caso del método cumplen; 0/12 de la línea base.
- 0 recursos duplicados frente a 10; 0 compensaciones duplicadas frente a 6.
- Control negativo 3/1: la idempotencia proviene de K5, no del doble.
- 14 llamadas externas frente a 38 (−63 %).

**No demostrado / pendiente:**
- **Aplicabilidad humana:** P1 y P2 no ejecutaron las sesiones; el observador independiente no está designado; hoja de observación, cuestionario y entrevista están en blanco.
- **Idempotencia distribuida:** el lock de D1 es de proceso; la garantía multi-instancia depende de Dc10 (índice único e inserción atómica), que no está aplicado.
- **Unicidad de la llave:** `CASO-A` tiene 2 filas y en producción hay 44 pares duplicados; la unicidad es una condición de despliegue, no una propiedad actual.
- **BUSA real:** la medición es sobre el doble neutro; no se invocó el servicio real.

## 4. Cierre

El ciclo sumativo **no está cerrado**. Falta ejecutar las sesiones humanas, llenar la matriz de aplicabilidad y analizar. La medición técnica es sólida y suficiente para la dimensión de utilidad; no sustituye la dimensión de aplicabilidad.

## 5. Referencias a verificar antes de citar

- Helland (2012): páginas del artículo en *ACM Queue*.
- Hummer et al. (2013): páginas en *ICSOC 2013*.
