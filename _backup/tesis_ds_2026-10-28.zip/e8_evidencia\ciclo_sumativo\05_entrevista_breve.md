# Entrevista breve (semiestructurada)

> 10–15 minutos, posterior al cuestionario. La conduce el observador independiente, no el autor.

## Guion

1. **Comprensión.** Cuénteme con sus palabras qué hace el método cuando el servicio externo no responde.
2. **Decisión.** ¿Cómo decidió qué hacer en el escenario de pérdida de respuesta? ¿En qué se apoyó?
3. **Compensación.** ¿Qué regla siguió para no compensar dos veces? ¿La consideró natural o contraintuitiva?
4. **Punto crítico.** ¿Hubo algún paso donde dudó o asumió algo? ¿Qué información le faltó?
5. **Aplicabilidad.** ¿Podría aplicarlo mañana en su trabajo? ¿Qué necesitaría?
6. **Mejora.** Si pudiera cambiar una sola cosa del método, ¿cuál sería y por qué?

## Registro

| Pregunta | Respuesta sintetizada | Cita textual relevante |
|:--|:--|:--|
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |
| 6 | | |

## Notas del observador

- Tono y actitud (confianza, frustración, duda):
- Ayudas prestadas (deberían ser cero):
- Incidencias de la sesión:
