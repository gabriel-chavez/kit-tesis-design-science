# Informe del Ciclo Sumativo (Etapa E8)

**Tesis de Maestría:** «Método para el diseño y la verificación de compensaciones idempotentes en transacciones distribuidas basadas en Sagas»  
**Etapa:** E8 — Evaluación Sumativa  
**Fecha:** 2026-10-28  
**Versión evaluada:** `E7e_MetodoCompensacion` (netstandard2.0), SHA-256 `ec9b8b6e8d37374ff28f2eb816285571ede997c47ec44a235da829d13dbd10bf`  
**Doble de evaluación:** `busa-eval-stub`, modo neutro (`localhost:5098`)  
**Entorno:** Aislado, sin invocación a BUSA real, datos sintéticos controlados.  

---

## Resumen Ejecutivo

En este informe se consolida la ejecución y el análisis técnico del ciclo sumativo (E8), cuyo propósito es juzgar formalmente el método de compensación idempotente (componentes K1 a K9) contra criterios de utilidad técnica congelados, comparándolo de manera rigurosa frente a la conducta actual del sistema (línea base con reintentos ciegos y espera fija).

La medición técnica se ejecutó sobre un **doble de evaluación neutro** que no deduplica por diseño, garantizando que cualquier propiedad de idempotencia provenga exclusivamente del artefacto evaluado. En los seis escenarios de fallo evaluados sobre dos casos reales de prueba (12 combinaciones escenario-caso), el método congelado cumplió el 100% (12/12) de los criterios de utilidad: **0 recursos duplicados**, **0 compensaciones duplicadas** y **0 estados inconsistentes**. En contraste, la línea base falló en el 100% de los casos (0/12), generando 10 recursos duplicados y 6 compensaciones redundantes. La neutralidad del entorno fue validada mediante un **control negativo** estricto (sin K5 duplica 3 veces; con K5 produce exactamente 1 efecto).

Las sesiones de interacción humana con los participantes independientes (P1 y P2) y el observador externo se declaran formalmente como **pendientes**, reportándose únicamente datos técnicos directos para preservar la integridad académica.

---

## 1. Marco Metodológico y Contexto

El ciclo sumativo E8 no busca rediseñar ni ajustar el artefacto, sino evaluar su efectividad final de acuerdo con los principios de Design Science Research (DSR) formulados por Hevner et al. (2004), Peffers et al. (2007) y el marco de evaluación de Venable et al. (2016). La separación ontológica entre el método formal (el artefacto conceptual) y su implementación en código sigue las directrices de Wieringa (2014).

### Cadena de Integración Evaluada
La arquitectura involucra un flujo multi-salto sin mensajería asíncrona:
$$\text{Cliente} \longrightarrow \text{PasarelaPagos (CNPagosQR)} \xrightarrow{\text{salto interno}} \text{UNIVidaNetPagosSimple (CPagoSimple)} \xrightarrow{\text{salto externo}} \text{BUSA}$$

Conforme a la decisión de diseño adoptada, el coordinador del método (K4 Motor de Decisión y K6 Ordenador de Compensaciones) reside en la capa de integración (`PasarelaPagos`), actuando bajo el principio rector de que **el estado del servicio externo es la única fuente de verdad**.

---

## 2. Diseño del Experimento Técnico

### 2.1 Llave de Identidad Unificada (Opción A)
Se formalizó el uso operativo de la llave natural:
$$\text{Llave} = (\text{TRAMITE\_SECUENCIAL}, \text{T\_PAR\_SIMPLE\_TRAMITE\_FK})$$
Eliminando la ambigüedad conceptual de referenciar `GESTION` como año calendario, dado que en la base de datos física representa el canal/tipo de trámite.

### 2.2 Casos de Prueba Fijos
1. **`CASO-A` (`63442 / 4`):** Operación con dos registros históricos en estado `ANULADO`, importe de Bs. 200,00. Utilizado para verificar el comportamiento ante registros duplicados previos y someter a prueba la restricción de unicidad de la decisión **Dc10**.
2. **`CASO-B` (`1598416 / 1`):** Operación control con un único registro histórico `ANULADO`, importe de Bs. 196,00, representativo del flujo normal.
3. *Caso Excluido:* Se descartó explícitamente el trámite `10565 / 4` debido a que contiene un registro `PAGADO`, lo que violaría la condición de contorno **Dc8** (el método no efectúa reversión financiera de pagos asentados).

### 2.3 Escenarios Evaluados
Se replicaron los seis escenarios de falla de la etapa E6:
- **E1:** Caída del servicio a mitad de la transacción.
- **E2:** Superación del tiempo de espera (timeout en salto externo).
- **E3:** Pérdida de respuesta tras procesamiento exitoso en el externo.
- **E4:** Solicitud duplicada concurrente.
- **E5:** Reintento del cliente tras éxito real confirmado.
- **E6:** Fallo transitorio al repetir una anulación/compensación.

---

## 3. Resultados de la Medición Técnica

### 3.1 Desempeño del Método Congelado
El artefacto bajo evaluación (SHA-256 `ec9b8b6e8d37374ff28f2eb816285571ede997c47ec44a235da829d13dbd10bf`) arrojó los siguientes resultados:

| Escenario | Recursos en BUSA | Compensaciones en BUSA | Decisión K4 | Inconsistencia | Cumplimiento |
|---|:---:|:---:|---|:---:|:---:|
| **E1 Caída a mitad** | 0 | 0 | `Reprocesar` | 0 | **Cumple** |
| **E2 Timeout** | 1 | 0 | `ConfirmarProcesada` | 0 | **Cumple** |
| **E3 Respuesta perdida** | 1 | 0 | `ConfirmarProcesada` | 0 | **Cumple** |
| **E4 Solicitud duplicada** | 1 | 0 | `ConfirmarProcesada` | 0 | **Cumple** |
| **E5 Reintento tras éxito** | 1 | 0 | `ConfirmarProcesada` | 0 | **Cumple** |
| **E6 Repetición anulación**| 1 | 1 | `Compensar` | 0 | **Cumple** |

*Nota:* Idéntico comportamiento obtenido en `CASO-A` y `CASO-B` (12/12 cumplidos).

### 3.2 Desempeño de la Línea Base (Conducta Actual)
Re-ejecutada sobre el mismo doble neutro con 5 reintentos y 150 ms de espera:

| Escenario | Recursos en BUSA | Compensaciones en BUSA | Estado Local | Inconsistencia | Cumplimiento |
|---|:---:|:---:|---|:---:|:---:|
| **E1 Caída a mitad** | 0 | 0 | `Error` (agotado) | 0 | **Falla** |
| **E2 Timeout** | **2 (duplicado)** | 0 | `Procesada` | 0 | **Falla** |
| **E3 Respuesta perdida** | **2 (duplicado)** | 0 | `Procesada` | 0 | **Falla** |
| **E4 Solicitud duplicada** | **3 (triplicado)**| 0 | `Procesada` | 0 | **Falla** |
| **E5 Reintento tras éxito**| **2 (duplicado)** | 0 | `Procesada` | 0 | **Falla** |
| **E6 Repetición anulación**| 1 | **4 (cuádruple)** | `Compensada` | 0 | **Falla** |

### 3.3 Tabla Comparativa Consolidada

| Métrica de Evaluación | Método Congelado | Línea Base (Conducta Actual) | Balance / Efecto |
|---|:---:|:---:|:---:|
| **Efectividad global (éxito en criterios)** | **12 / 12 (100%)** | 0 / 12 (0%) | **+12 éxitos** |
| **Recursos duplicados creados** | **0** | 10 | **−10 duplicaciones** |
| **Compensaciones duplicadas** | **0** | 6 | **−6 duplicaciones** |
| **Estados inconsistentes al cierre** | **0** | 0 | 0 |
| **Consultas de verificación externa (K3)** | 6 | 0 | +6 consultas |
| **Llamadas externas totales ejecutadas** | **14** | 38 | **−24 llamadas (−63%)** |

---

## 4. Validación del Entorno: Control Negativo

Para garantizar que el doble no introdujo sesgos de deduplicación implícita, se ejecutaron tres invocaciones idénticas de compensación:

$$\begin{aligned}
\text{Sin K5 (Control Negativo)} &\implies 3 \text{ compensaciones efectivas en BUSA (Efecto multiplicado)} \\
\text{Con K5 (Método congelado)} &\implies 1 \text{ compensación efectiva en BUSA (Efecto idempotente)}
\end{aligned}$$

Este resultado se confirmó en `CASO-A` y `CASO-B`, validando que la idempotencia es aportada por el diseño del método y no por la infraestructura subyacente.

---

## 5. Análisis Técnico de Causalidad

1. **Mecanismo ante timeout y pérdida de respuesta (E2 y E3):**  
   El componente K3 consulta activamente el estado en el proveedor externo antes de permitir un reintento. Esto rompe la indistinguibilidad clásica entre fallo previo y fallo posterior, transformando un escenario de duplicación inminente en una confirmación idempotente de recurso existente.
2. **Mecanismo de deduplicación de solicitudes (E4 y E5):**  
   La derivación determinista de la llave K1 sobre `(TRAMITE_SECUENCIAL, T_PAR_SIMPLE_TRAMITE_FK)` combinada con la guarda de estado en bitácora local (K2) intercepta reintentos idénticos sin reenviarlos a la red.
3. **Mecanismo de compensación idempotente (E6):**  
   El patrón de *Reserva Previa* implementado en K5 (registrar la compensación en estado `Registrada` con clave única sobre `(OPERACION_LOGICA, MOTIVO)` previo a la llamada HTTP) neutraliza cualquier intento de re-anulación redundante, absorbiendo caídas intermedias del proceso.
4. **Costo computacional del método:**  
   El beneficio del método se adquiere a expensas de introducir tráfico de consulta (K3) en los flujos de excepción y una penalización de latencia equivalente al tiempo de espera de verificación.

---

## 6. Estado de las Sesiones Humanas y Observador

Conforme al protocolo de investigación:
- **Participante P1 (Leonel Chamaca Lima):** Asignado a `CASO-A`. Sesión pendiente de ejecución.
- **Participante P2 (Ernesto Gutierrez):** Asignado a `CASO-B`. Sesión pendiente de ejecución.
- **Observador Independiente:** En proceso de designación formal por la coordinación de tesis.

Debido a que las sesiones no se ejecutaron en esta estación técnica, **los criterios de aplicabilidad humana (≥ 80% de tareas sin ayuda y ausencia de fallos unánimes en puntos críticos) se reportan formalmente como no evaluados**, impidiendo dar por cerrada la dimensión cualitativa del ciclo sumativo.

---

## 7. Amenazas a la Validez Declaradas

1. **Constructo:** El simulador `busa-eval-stub` es un doble controlado; no replica la latencia estocástica ni fallos internos no documentados de BUSA real.
2. **Validez Interna:** El mecanismo de sincronización local utiliza un lock en memoria (`D1`), el cual solo protege la concurrencia a nivel de proceso único.
3. **Validez Externa:** La evaluación se circunscribe a un exemplar específico del dominio SOAT. La generalización teórica es analítica hacia la clase de "integraciones multi-salto sobre servicios externos no transaccionales", no estadística hacia otras plataformas.
4. **Condición de Despliegue Dc10:** Se reitera que la garantía de idempotencia en un clúster balanceado multi-instancia depende de la creación física del índice único en SQL Server.

---

## 8. Conclusión

La evidencia técnica obtenida en la etapa E8 demuestra de manera concluyente que el método congelado previene la duplicación de efectos transaccionales y garantiza la convergencia hacia un estado final invariante en los seis escenarios evaluados sobre el doble neutro.

La declaración de alcance rigurosa para la tesis queda formulada de la siguiente manera:
> *La idempotencia de la operación y de la compensación ha sido verificada empíricamente en una instancia de ejecución sobre un doble neutro; la garantía en entornos distribuidos multi-instancia queda supeditada al cumplimiento de la condición de despliegue Dc10 (índice único en base de datos).*

---

## Referencias

García-Molina, H., & Salem, K. (1987). Sagas. *Proceedings of the 1987 ACM SIGMOD International Conference on Management of Data*, 249–259. https://doi.org/10.1145/38713.38742

Helland, P. (2012). Idempotence is not a medical condition. *ACM Queue*, 10(4), 1–11. https://doi.org/10.1145/2181796.2187821

Hevner, A. R., March, S. T., Park, J., & Ram, S. (2004). Design science in information systems research. *MIS Quarterly*, 28(1), 75–105. https://doi.org/10.5555/2017212.2017217

Hummer, W., Rosenberg, F., Oliveira, F., & Eilam, T. (2013). Testing idempotence for infrastructure as code. *Service-Oriented Computing (ICSOC 2013)*, 368–382. https://doi.org/10.1007/978-3-642-45065-5_19

Peffers, K., Tuunanen, T., Rothenberger, M. A., & Chatterjee, S. (2007). A design science research methodology for information systems research. *Journal of Management Information Systems*, 24(3), 45–77. https://doi.org/10.2753/MIS0742-1222240302

Venable, J., Pries-Heje, J., & Baskerville, R. (2016). FEDS: a framework for evaluation in design science research. *European Journal of Information Systems*, 25(1), 77–89. https://doi.org/10.1057/ejis.2014.36

Wieringa, R. J. (2014). *Design science methodology for information systems and software engineering*. Springer. https://doi.org/10.1007/978-3-662-43839-8

Yin, R. K. (2018). *Case study research and applications: Design and methods* (6.ª ed.). SAGE Publications.
