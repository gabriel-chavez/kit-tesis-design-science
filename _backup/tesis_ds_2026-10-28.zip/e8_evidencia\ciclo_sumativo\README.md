# Ciclo sumativo E8 — Kit de ejecución

> **Versión congelada:** `ec9b8b6…` — **no se modifica** durante este ciclo.
> **Objetivo:** juzgar el método contra los criterios congelados y medir aplicabilidad y efectividad con practicantes independientes.

## Qué tienes que hacer (lo humano)

1. **Reclutar 2–3 practicantes independientes** (no el autor). Si puedes, uno externo a la organización.
2. **Asignar casos distintos** a cada participante (no todos el 3147).
3. **Nombrar un observador independiente** (no el autor) que registre decisiones, errores, tiempos y ayudas.
4. **Aleatorizar el orden** de los escenarios por participante.
5. **Ejecutar** el método congelado contra el doble neutro y correr el **control negativo** en cada sesión.
6. **Recoger** telemetría, contadores del doble y las hojas de observación.
7. **Analizar** con conteos exactos y declarar las amenazas.

## Archivos

| Archivo | Para qué |
|:--|:--|
| `01_diseno_sumativo.md` | Diseño, muestra, comparación con la línea base, congelación |
| `02_guion_escenarios.md` | Guion por escenario con criterio de éxito |
| `03_hoja_observacion.md` | Registro por participante × escenario |
| `04_cuestionario_posterior.md` | Claridad, esfuerzo, confianza |
| `05_entrevista_breve.md` | Entrevista semiestructurada |
| `06_matriz_analisis.md` | Tabla por escenario y participante + comparación |
| `07_amenazas_validez.md` | Amenazas y mitigaciones |

## Criterio de éxito (congelado)

- Los **tres criterios de utilidad** se cumplen en todos los escenarios.
- **≥ 80 %** de tareas sin ayuda y **ningún punto crítico fallado por todos**.
- **Ningún defecto crítico** sin resolver o sin declarar.
