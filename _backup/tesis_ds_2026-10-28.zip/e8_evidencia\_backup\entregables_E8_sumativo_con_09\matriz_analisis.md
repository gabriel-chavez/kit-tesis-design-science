# Matriz de análisis — Ciclo sumativo (E8)

**Versión congelada:** `E7e_MetodoCompensacion`, SHA-256 `ec9b8b6e8d37374ff28f2eb816285571ede997c47ec44a235da829d13dbd10bf`  
**Fecha de corrida técnica:** 2026-10-28  
**Tipo de generalización:** Analítica (mecanismos causales), no estadística ($n = 2$).  

---

## 1. Matriz Técnica por Caso y Escenario

### CASO-A — P1 (`63442 / 4`, Duplicado histórico)

| Escenario | Enfoque | Recursos | Compensaciones | Estado bitácora | Estado externo | Decisión K4 | Llamadas | Consultas | Latencia (ms) | Inconsistente | Cumple |
|---|---|:---:|:---:|---|---|---|:---:|:---:|:---:|:---:|:---:|
| **E1 Caída a mitad** | Método | 0 | 0 | NoProcesada | SOLICITADO | Reprocesar | 1 | 1 | 31 | 0 | **Sí** |
| | Línea base | 0 | 0 | Error | SOLICITADO | Sin K4 | 5 | 0 | 785 | 0 | **No** |
| **E2 Timeout** | Método | 1 | 0 | Procesada | SOLICITADO | ConfirmarProcesada | 1 | 1 | 2015 | 0 | **Sí** |
| | Línea base | 2 | 0 | Procesada | SOLICITADO | Sin K4 | 2 | 0 | 2167 | 0 | **No** |
| **E3 Respuesta perdida** | Método | 1 | 0 | Procesada | SOLICITADO | ConfirmarProcesada | 1 | 1 | 2 | 0 | **Sí** |
| | Línea base | 2 | 0 | Procesada | SOLICITADO | Sin K4 | 2 | 0 | 160 | 0 | **No** |
| **E4 Solicitud duplicada**| Método | 1 | 0 | Procesada | SOLICITADO | ConfirmarProcesada | 1 | 0 | 1 | 0 | **Sí** |
| | Línea base | 3 | 0 | Procesada | SOLICITADO | Sin K4 | 3 | 0 | 1 | 0 | **No** |
| **E5 Reintento tras éxito**| Método | 1 | 0 | Procesada | SOLICITADO | ConfirmarProcesada | 1 | 0 | 0 | 0 | **Sí** |
| | Línea base | 2 | 0 | Procesada | SOLICITADO | Sin K4 | 2 | 0 | 1 | 0 | **No** |
| **E6 Fallo al repetir anulación** | Método | 1 | 1 | Compensada | ANULADO | Compensar | 2 | 0 | 5 | 0 | **Sí** |
| | Línea base | 1 | 4 | Compensada | ANULADO | Sin K4 | 5 | 0 | 160 | 0 | **No** |

---

### CASO-B — P2 (`1598416 / 1`, Control limpio)

| Escenario | Enfoque | Recursos | Compensaciones | Estado bitácora | Estado externo | Decisión K4 | Llamadas | Consultas | Latencia (ms) | Inconsistente | Cumple |
|---|---|:---:|:---:|---|---|---|:---:|:---:|:---:|:---:|:---:|
| **E1 Caída a mitad** | Método | 0 | 0 | NoProcesada | SOLICITADO | Reprocesar | 1 | 1 | 2 | 0 | **Sí** |
| | Línea base | 0 | 0 | Error | SOLICITADO | Sin K4 | 5 | 0 | 780 | 0 | **No** |
| **E2 Timeout** | Método | 1 | 0 | Procesada | SOLICITADO | ConfirmarProcesada | 1 | 1 | 2014 | 0 | **Sí** |
| | Línea base | 2 | 0 | Procesada | SOLICITADO | Sin K4 | 2 | 0 | 2163 | 0 | **No** |
| **E3 Respuesta perdida** | Método | 1 | 0 | Procesada | SOLICITADO | ConfirmarProcesada | 1 | 1 | 2 | 0 | **Sí** |
| | Línea base | 2 | 0 | Procesada | SOLICITADO | Sin K4 | 2 | 0 | 154 | 0 | **No** |
| **E4 Solicitud duplicada**| Método | 1 | 0 | Procesada | SOLICITADO | ConfirmarProcesada | 1 | 0 | 0 | 0 | **Sí** |
| | Línea base | 3 | 0 | Procesada | SOLICITADO | Sin K4 | 3 | 0 | 2 | 0 | **No** |
| **E5 Reintento tras éxito**| Método | 1 | 0 | Procesada | SOLICITADO | ConfirmarProcesada | 1 | 0 | 1 | 0 | **Sí** |
| | Línea base | 2 | 0 | Procesada | SOLICITADO | Sin K4 | 2 | 0 | 0 | 0 | **No** |
| **E6 Fallo al repetir anulación** | Método | 1 | 1 | Compensada | ANULADO | Compensar | 2 | 0 | 2 | 0 | **Sí** |
| | Línea base | 1 | 4 | Compensada | ANULADO | Sin K4 | 5 | 0 | 158 | 0 | **No** |

---

## 2. Resumen Comparativo de Utilidad Técnica

| Criterio Congelado | Método Congelado | Línea Base (mismo doble neutro) | Diferencia Absoluta |
|---|:---:|:---:|:---:|
| **Compensaciones con efecto duplicado** | **0** | 6 | **−6** |
| **Operaciones con estado inconsistente** | **0** | 0 | 0 |
| **Invariancia del estado final (N de N)** | **12 / 12** | 0 / 12 | **+12** |
| **Recursos duplicados creados** | **0** | 10 | **−10** |
| **Consultas de verificación de estado (K3)** | 6 | 0 | +6 |
| **Invocaciones externas brutas** | 14 | 38 | −24 |

---

## 3. Matriz de Sesiones Humanas (Declaración de Estado)

| Escenario | P1 (Leonel Chamaca) - Decisión | P1 ¿Sin ayuda? | P1 Duplicados | P2 (Ernesto Arce) - Decisión | P2 ¿Sin ayuda? | P2 Duplicados |
|---|:---:|:---:|:---:|:---:|:---:|:---:|
| E1 Caída a mitad | *Pendiente* | *Pendiente* | *Pendiente* | *Pendiente* | *Pendiente* | *Pendiente* |
| E2 Timeout | *Pendiente* | *Pendiente* | *Pendiente* | *Pendiente* | *Pendiente* | *Pendiente* |
| E3 Respuesta perdida | *Pendiente* | *Pendiente* | *Pendiente* | *Pendiente* | *Pendiente* | *Pendiente* |
| E4 Duplicada | *Pendiente* | *Pendiente* | *Pendiente* | *Pendiente* | *Pendiente* | *Pendiente* |
| E5 Reintento tras éxito | *Pendiente* | *Pendiente* | *Pendiente* | *Pendiente* | *Pendiente* | *Pendiente* |
| E6 Repetir anulación | *Pendiente* | *Pendiente* | *Pendiente* | *Pendiente* | *Pendiente* | *Pendiente* |

### Resumen de Aplicabilidad Humana

| Métrica | Participante P1 | Participante P2 | Total / Promedio |
|---|:---:|:---:|:---:|
| Tareas resueltas sin ayuda | *Pendiente de sesión* | *Pendiente de sesión* | *Pendiente* |
| Puntos críticos a la primera | *Pendiente de sesión* | *Pendiente de sesión* | *Pendiente* |
| Tiempo total de sesión | *Pendiente de sesión* | *Pendiente de sesión* | *Pendiente* |
| Ambigüedades declaradas | *Pendiente de sesión* | *Pendiente de sesión* | *Pendiente* |

> **Nota metodológica:** Las celdas permanecen en estado pendiente conforme al principio de no inventar datos de participantes ni sustituir al observador independiente.

---

## 4. Síntesis y Reglas de Análisis

1. **Cumplimiento de Criterios de Utilidad:** Los tres criterios de utilidad técnica se cumplen al 100% en los 12 casos evaluados del método congelado.
2. **Criterios de Aplicabilidad Humana:** Permanecen en estado no evaluable hasta que se desarrollen las sesiones presenciales con observador externo.
3. **Casos donde el método no mejora:**
   - En **E1**, ambos enfoques finalizan con 0 recursos creados; el beneficio del método radica en la decisión semántica correcta (`Reprocesar` vs `Error` ciego tras 5 intentos).
   - En **Latencia**, el método incurre en la penalización deliberada de la consulta de verificación (K3) en E2 y E3 frente a un reintento ciego.
4. **Generalización Analítica:** No se infieren probabilidades poblacionales. Se valida el mecanismo de causalidad técnica: la verificación ante sospecha y el registro previo de compensación previenen determinísticamente los efectos colaterales en servicios externos no transaccionales.
