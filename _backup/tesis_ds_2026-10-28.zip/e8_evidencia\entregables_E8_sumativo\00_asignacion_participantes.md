# Asignación de participantes y casos

**Fecha de preparación:** 2026-10-28
**Estado de las sesiones:** pendientes de ejecución.

## Participantes

| Código | Participante | Perfil | Caso | Llave | Orden de escenarios |
|---|---|---|---|---|---|
| **P1** | Leonel Chamaca Lima | Desarrollador .NET/WCF; participó en el walkthrough de E7e | **CASO-A** | `TRAMITE_SECUENCIAL = 63442`, `T_PAR_SIMPLE_TRAMITE_FK = 4` | Orden 1 (registrado antes de la sesión) |
| **P2** | Ernesto Gutierrez | Analista/desarrollador con 1+ año; sin exposición previa al método | **CASO-B** | `TRAMITE_SECUENCIAL = 1598416`, `T_PAR_SIMPLE_TRAMITE_FK = 1` | Orden 2 (registrado antes de la sesión) |

## Casos

| Caso | Detalle | Uso |
|---|---|---|
| **CASO-A** | 2 filas `ANULADO`, importe 200,00, 2026-01-23. Duplicado histórico de la misma llave lógica. | Prueba Dc10 y la unicidad de la operación. |
| **CASO-B** | 1 fila `ANULADO`, importe 196,00, 2025-12-31. Sin duplicado. | Control. |

- Casos distintos; ninguno es 3147/2026 en ambos.
- Se excluye `10565/4` porque tiene una fila `PAGADO` y cruzaría Dc8 (no reversión de pagos).
- Los identificadores se usan solo como llaves lógicas; no se exponen datos personales.

## Observador independiente

**Micaela Machicado.** No es el autor. Debe registrar decisiones, errores, tiempos y ayudas en la hoja de observación.

## Reglas de la sesión

1. El participante aplica el método; el observador registra; el autor no interviene.
2. El orden de escenarios se registra antes de iniciar y no se cambia.
3. No se completan hojas ni cuestionarios sin el participante.
4. El control negativo se ejecuta en cada corrida.
5. La versión evaluada es la congelada `ec9b8b6…`; no se modifica.
