# Mapeo de la identidad K1 — punto a declarar antes del sumativo

> **Problema:** el método (K1/Dc1) llama a la llave `(TRAMITE_NUMERO, GESTION)`; la base usa `(TRAMITE_SECUENCIAL, T_PAR_SIMPLE_TRAMITE_FK)`. Si `GESTION` significa **año**, el mapeo no coincide con la base.

## 1. Lo que dice hoy la tesis

- `07b_requisitos.md`: «`TRAMITE_NUMERO` + `GESTION` (por ejemplo, `6901XUL` + `2025`), único por año».
- `07c_diseno_artefacto.md` (Dc1): llave derivada de `(TRAMITE_NUMERO, GESTION)`; «el identificador ya es único por año».
- `e7e` (evidencia): la llave usada fue `(TRAMITE_SECUENCIAL, T_PAR_SIMPLE_TRAMITE_FK)`, p. ej. `7400|1`.

## 2. Lo que dice la base

| Notación del método | Columna real | Significado |
|:--|:--|:--|
| `TRAMITE_NUMERO` | `TRAMITE_SECUENCIAL` | Número/secuencial del trámite |
| `GESTION` | `T_PAR_SIMPLE_TRAMITE_FK` | **Canal/tipo de trámite** (1 = APP Móvil, 4 = POS), **no el año** |

La unicidad real observada es `(TRAMITE_SECUENCIAL, T_PAR_SIMPLE_TRAMITE_FK)`.

## 3. La inconsistencia

Si `GESTION` = año, entonces:

- la llave del método `(TRAMITE_NUMERO, año)` **no es** la llave real `(TRAMITE_SECUENCIAL, canal)`;
- el año no está en la llave real que usa la base y la evidencia;
- el texto de `07b`/`07c` y el código no hablan de lo mismo.

Esto no invalida la evidencia (la implementación usó la llave real), pero **sí invalida la notación** si un evaluador la lee literalmente.

## 4. Opciones de resolución

| Opción | Qué se hace | Ventaja | Costo |
|:--|:--|:--|:--|
| **A. Corregir la notación (recomendada)** | Renombrar la llave del método a `(TRAMITE_SECUENCIAL, T_PAR_SIMPLE_TRAMITE_FK)`; dejar de llamar `GESTION` al segundo componente | Coincide con la base, el código y la evidencia | Hay que corregir `07b`, `07c` (Dc1) y `metodo.md` |
| **B. Mantener `(TRAMITE_NUMERO, GESTION)` y mapear** | Declarar que `TRAMITE_NUMERO` = `TRAMITE_SECUENCIAL` y `GESTION` = `T_PAR_SIMPLE_TRAMITE_FK` (no año) | Conserva la notación | Queda un término engañoso; un evaluador preguntará por qué "gestión" no es el año |
| **C. Si `GESTION` debe ser año** | Buscar/confirmar la columna de año y verificar si `(TRAMITE_SECUENCIAL, año)` es única | Mantiene el sentido literal | Si la unicidad real es por canal, la llave sería incompleta o incorrecta |

## 5. Decisión adoptada (2026-10-28)

**Opción A.** La llave operativa del método es `(TRAMITE_SECUENCIAL, T_PAR_SIMPLE_TRAMITE_FK)`. Se elimina la notación `(TRAMITE_NUMERO, GESTION)` y el uso de `GESTION` como año:

> `TRAMITE_NUMERO` → `TRAMITE_SECUENCIAL`
> `GESTION` → `T_PAR_SIMPLE_TRAMITE_FK` (canal/tipo de trámite, **no** año)

La implementación, la evidencia y la tesis deben usar la misma llave.

## 6. Qué hay que tocar (en la sesión de tesis)

Pendiente en la sesión de tesis (aquí no se tocó `tesis_ds`):

- `07b_requisitos.md`: fila del identificador.
- `07c_diseno_artefacto.md`: Dc1.
- `metodo.md` (copia de trabajo): **ya actualizado**.
- `08_evaluacion.md` / protocolo: nota de mapeo antes de ejecutar.

## 7. Para el sumativo

La ejecución usa la llave real `(TRAMITE_SECUENCIAL, T_PAR_SIMPLE_TRAMITE_FK)`. La tesis, la evidencia y el código deben declarar el mismo mapeo.

## 8. Casos del sumativo

- `CASO-A`: `63442 / 4` — 2 filas `ANULADO` (duplicado real; prueba Dc10).
- `CASO-B`: `1598416 / 1` — 1 fila `ANULADO` (control).
- Excluido `10565/4`: tiene una fila `PAGADO` y cruzaría **Dc8**.
