# Análisis Predictivo de Aplicabilidad y Modelo de Referencia Cognitivo (Etapa E8)

**Tesis de Maestría:** «Método para el diseño y la verificación de compensaciones idempotentes en transacciones distribuidas basadas en Sagas»  
**Documento:** Entregable Metodológico de Referencia Cognitiva (Baseline de Contraste para Sesiones Humanas)  
**Fecha:** 2026-10-28  
**Autor / Rol:** Asistente de Investigación e Ingeniería de Software Senior  

---

## 1. Propósito Metodológico del Entregable

En el marco de Design Science Research (Hevner et al., 2004; Wieringa, 2014), la evaluación de un método formal no solo comprende su verificación técnica algorítmica, sino también la anticipación analítica de su **usabilidad cognitiva y transferibilidad** a ingenieros de software.

Este documento formaliza el **Cognitive Walkthrough Predictivo** (Wharton et al., 1994), sirviendo como modelo analítico de referencia (baseline de comportamiento esperado) para contrastar los mecanismos de decisión técnica frente a los resultados empíricos que se obtengan en las sesiones presenciales con los participantes independientes:
- **Participante P1 (Leonel Chamaca Lima):** Evaluador con familiaridad previa con el ecosistema de la pasarela de pagos. Asignado a `CASO-A` (`63442 / 4`, escenario con historial de duplicados en BD).
- **Participante P2 (Ernesto Arce):** Evaluador independiente externo al desarrollo previo del sistema. Asignado a `CASO-B` (`1598416 / 1`, control limpio).

---

## 2. Modelado de Decisiones y Análisis de Fricción Cognitiva por Escenario

| Escenario de Falla | Comportamiento Prescrito por el Método (K4) | Inercia Intuitiva Habitual (Línea Base / Práctica CRUD) | Fricción Cognitiva Anticipada | Hipótesis de Desviación / Error |
|---|---|---|---|---|
| **E1. Caída a mitad de transacción** | Decidir `Reprocesar` tras verificar ausencia de efecto en BUSA. | Reintentar inmediatamente la llamada de red o abortar con error no recuperable. | Incertidumbre sobre si la caída interrumpió la solicitud antes o después de abandonar el nodo local. | **Baja probabilidad de error:** Al constatar ausencia de registro externo, la deducción lógica converge a reprocesar. |
| **E2. Timeout en llamada externa** | Consultar estado en BUSA (`K3`); si está creado, `ConfirmarProcesada` sin regenerar QR. | Reintentar la llamada de generación de QR a ciegas. | **Alta:** Fuerte sesgo de los programadores a confiar en el estado local de su base de datos (`SOLICITADO`) en lugar de consultar la fuente de verdad externa. | **Alta (Punto Crítico):** Riesgo elevado de que el desarrollador asuma que "timeout = fallo", provocando duplicación del recurso en BUSA. |
| **E3. Pérdida de respuesta tras éxito** | `ConfirmarProcesada` adoptando el identificador del QR confirmado externamente. | Reintentar la transacción completa o marcar la operación como fallida. | Dificultad para discernir entre un fallo de red local y una desconexión unilateral post-procesamiento del banco. | **Media:** Sin la consulta K3, el desarrollador tiende a forzar un reintento que generará inconsistencia. |
| **E4. Solicitud duplicada concurrente** | La guarda de estado y la llave determinista K1 interceptan la petición; `ConfirmarProcesada`. | Tratar cada petición HTTP entrante como una nueva transacción independiente. | Duda sobre si rechazar la segunda petición arrojando una excepción HTTP o retornar el recurso existente transparentemente. | **Baja a Media:** Depende de si el desarrollador concibe la idempotencia como transparencia de respuesta o como excepción. |
| **E5. Reintento del cliente tras éxito** | `ConfirmarProcesada` retornando el QR ya existente sin invocar a BUSA. | Generar un nuevo QR y sobrescribir el registro previo en base de datos. | Asumir que si el usuario presiona nuevamente el botón de pago, "desea un trámite nuevo". | **Media:** Si el desarrollador utiliza UUIDs aleatorios por request, generará duplicación forzosa. |
| **E6. Fallo al repetir anulación** | Aplicar el patrón de *Reserva Previa*: registrar `Registrada` antes de llamar a BUSA y confirmar a `Aplicada`. | Invocar la anulación en BUSA y, si responde `0000`, insertar el registro en base de datos. | **Muy Alta:** La inercia tradicional del desarrollo de software dicta que "no se persiste en BD hasta que el servicio externo responda exitoso". | **Muy Alta (Punto Crítico Central):** Es el punto donde la intuición CRUD falla sistemáticamente frente al diseño de sistemas distribuidos robustos. |

---

## 3. Puntos Críticos de Fricción Conceptual Documentados

Para guiar la auditoría del observador independiente durante las sesiones reales, se han categorizado las tres principales fuentes de ambigüedad técnica que enfrentará un programador:

### 3.1 Ambigüedad Terminológica: `PENDIENTE` vs. Contrato BUSA
- **Comportamiento analizado:** Un desarrollador que inspeccione el contrato WCF de BUSA (`UNIVIDA_*_QR_002`) constatará que el banco únicamente retorna caracteres de estado: `H` (Habilitado), `P` (Pagado), `A` (Anulado) y `V` (Vencido).
- **Riesgo:** Pérdida de tiempo del evaluador buscando un literal `"PENDIENTE"` inexistente en los payloads.
- **Principio del método:** Clarificar que `PENDIENTE` es una categoría sintética interna de la pasarela para designar el estado **indeterminado** ante timeouts de verificación.

### 3.2 Mapeo de Identidad: `GESTION` vs. Columnas de Base de Datos
- **Comportamiento analizado:** El evaluador P2 (externo) asociará mentalmente la palabra `GESTIÓN` con el año calendario (e.g., 2026).
- **Riesgo:** Inconsistencia de clave al notar que en `PAGO_SIMPLE.T_QR_SOLICITUD` la columna es `T_PAR_SIMPLE_TRAMITE_FK`, correspondiente al canal o tipo de trámite (1 = Móvil, 4 = POS).
- **Principio del método:** Aplicar estrictamente la formalización de la Opción A: la clave lógica operativa es `(TRAMITE_SECUENCIAL, T_PAR_SIMPLE_TRAMITE_FK)`.

### 3.3 El Orden de Persistencia en Compensaciones: Reserva-Ejecución-Confirmación
- **Comportamiento analizado:** En el paradigma de programación secuencial común, la persistencia se condiciona al éxito de la llamada externa:
  $$\text{Llamada externa OK} \longrightarrow \text{INSERT en BD}$$
- **Riesgo crítico:** Si el nodo colapsa tras la anulación externa pero antes del guardado en BD, el sistema queda amnésico y reintentará anular en el siguiente ciclo.
- **Principio del método:** Imponer la regla de *reserva previa*:
  $$\text{INSERT ('Registrada')} \longrightarrow \text{Llamada externa} \longrightarrow \text{UPDATE ('Aplicada')}$$

---

## 4. Matriz de Hipótesis Comportamentales para Contraste Empírico

Esta matriz establece las predicciones formales previas a la recolección de datos de campo, permitiendo al investigador contrastar hipótesis en el capítulo de discusión de la tesis:

| Dimensión de Análisis | Hipótesis P1 (Leonel Chamaca Lima) | Hipótesis P2 (Ernesto Arce) |
|---|---|---|
| **Perfil y Contexto** | Familiarizado con la arquitectura previa de pagos SOAT. | Externo; primera interacción con las especificaciones del método. |
| **Autonomía Global Estimada** | Alta ($\approx 83\%$, 5 de 6 escenarios resueltos sin asistencia). | Moderada ($\approx 67\%$, 4 de 6 escenarios resueltos sin asistencia). |
| **Tiempo de Resolución Promedio** | 3 a 5 minutos por escenario (recorrido fluido de contratos). | 6 a 10 minutos por escenario (inspección detallada de esquemas). |
| **Desempeño en Punto Crítico E2** | Favorable: tiende a consultar BUSA por conocimiento del servicio de verificación. | Riesgo de asumir estado local `SOLICITADO` en primera instancia. |
| **Desempeño en Punto Crítico E6** | Riesgo medio de plantear ejecución previa por costumbre CRUD. | **Riesgo muy alto** de plantear ejecución previa a la persistencia. |
| **Principal Ambigüedad Reportada** | La presencia de 2 registros históricos en el `CASO-A` y el estado de la condición Dc10. | La denominación de `GESTION` como canal y no como año calendario. |

---

## 5. Instrucciones para la Triangulación de Resultados

Una vez que el observador independiente y los participantes ejecuten las sesiones presenciales y completen los instrumentos ([03_hoja_observacion.md](file:///C:/Users/lchavez/Documents/Proyecto%20predeterminado/e8_ciclo_sumativo/03_hoja_observacion.md), [04_cuestionario_posterior.md](file:///C:/Users/lchavez/Documents/Proyecto%20predeterminado/e8_ciclo_sumativo/04_cuestionario_posterior.md) y [05_entrevista_breve.md](file:///C:/Users/lchavez/Documents/Proyecto%20predeterminado/e8_ciclo_sumativo/05_entrevista_breve.md)), el tesista deberá:

1. **Cotejar los tiempos reales vs. los predichos:** Verificar si la familiaridad previa de P1 redujo efectivamente la latencia de decisión frente a P2.
2. **Evaluar la tasa de caída en puntos críticos:** Contrastar si la hipótesis de inercia CRUD en E6 se manifestó empíricamente en ambos perfiles.
3. **Consolidar la discusión académica:** Redactar en la tesis la convergencia o divergencia entre el modelo predictivo analítico y la evidencia observada en los evaluadores reales.
