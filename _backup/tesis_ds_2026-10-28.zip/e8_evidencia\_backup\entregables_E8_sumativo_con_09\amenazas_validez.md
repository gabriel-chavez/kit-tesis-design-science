# Amenazas a la validez del ciclo sumativo (E8)

**Versión congelada:** `E7e_MetodoCompensacion`, SHA-256 `ec9b8b6e8d37374ff28f2eb816285571ede997c47ec44a235da829d13dbd10bf`  
**Fecha:** 2026-10-28  

En concordancia con el marco de evaluación rigurosa para Design Science Research (Hevner et al., 2004; Peffers et al., 2007; Wieringa, 2014), se detallan las amenazas identificadas, sus estrategias de mitigación aplicadas y el **impacto residual** que no puede ser eliminado del experimento.

---

## 1. Validez de Constructo

| Amenaza | Mitigación Aplicada | Impacto Residual |
|---|---|---|
| **El doble de evaluación no es BUSA real** | Se declara explícitamente la condición de contorno. El cliente WCF de integración y los contratos SOAP/REST son idénticos a los de producción. | El comportamiento no documentado, variabilidad de red real o latencias anómalas del banco quedan fuera de la medición. |
| **La compensación del exemplar es la anulación de QR, no reversión de pagos** | Se formaliza la decisión **Dc8** y **Dc13**: el método es agnóstico a la acción compensatoria; en este dominio BUSA no expone reversión de pagos ejecutados. | No se evalúa reversión bancaria de fondos ya asentados. |
| **Riesgo de que el simulador deduplique por construcción** | Ejecución obligatoria de un **control negativo** en cada corrida (sin K5 = 3 efectos; con K5 = 1 efecto). | Si el control negativo fallara, la corrida completa se invalidaría. Al confirmarse, se demuestra que la neutralidad del doble es absoluta. |

---

## 2. Validez Interna

| Amenaza | Mitigación Aplicada | Impacto Residual |
|---|---|---|
| **Efecto de aprendizaje entre escenarios** | Orden de escenarios estrictamente aleatorizado y pre-registrado para cada participante (P1 y P2). | Con una muestra de $n = 2$, el contrabalanceo de orden no elimina completamente la familiarización progresiva. |
| **Sesgo del observador** | Nombramiento de un observador independiente (no el autor) guiado por una hoja de registro pre-estructurada. | El observador conoce la hipótesis de investigación general de la tesis. |
| **Sesgo del constructor (Author Bias)** | El autor no participa como sujeto evaluador ni como observador independiente en las sesiones. | La preparación del entorno técnico y de los instrumentos sigue a cargo del autor. |
| **Invalidez por comparación histórica contra E6** | Re-ejecución completa y sincrónica de la línea base sobre el **mismo doble neutro**, evitando comparar mediciones contra el doble idempotente de E6. | La línea base se modela como reintentos con espera fija de 150 ms (vs 1 s de producción) para no penalizar tiempos. |
| **Sincronización por bloqueo en memoria (Lock D1)** | Declaración explícita de que el lock en memoria solo protege concurrencia dentro del mismo proceso. | La garantía en entornos de clúster multiserver recae en la base de datos (**Dc10**). |

---

## 3. Validez Externa (Transferibilidad)

| Amenaza | Mitigación Aplicada | Impacto Residual |
|---|---|---|
| **Evaluación circunscrita a una sola organización** | Se busca incorporar al menos un participante sin experiencia previa en el sistema (Ernesto Arce, P2). | La representatividad se limita al ecosistema corporativo analizado. |
| **Especificidad del flujo transaccional** | Uso de dos casos de datos reales con naturalezas opuestas: CASO-A (duplicado histórico, prueba Dc10) y CASO-B (control limpio). | No se garantiza aplicabilidad directa en arquitecturas basadas en eventos o mensajería asíncrona. |
| **Entorno de ejecución de instancia única** | Declaración de que la prueba se ejecuta en un único nodo de pasarela. | La idempotencia distribuida multinodo queda como propiedad condicionada a la infraestructura de base de datos. |

---

## 4. Validez de Conclusión

| Amenaza | Mitigación Aplicada | Impacto Residual |
|---|---|---|
| **Muestra humana reducida ($n = 2$)** | Presentación de conteos exactos absolutos; prohibición expresa de inferir tasas porcentuales o pruebas estadísticas inferenciales; adopción de **generalización analítica** (Yin, 2018). | No existe significancia estadística formal ni cálculo de $p$-values. |
| **Número reducido de repeticiones de red** | Medición determinista de 6 escenarios $\times$ 2 casos $\times$ 2 enfoques (24 ejecuciones estructuradas). | No se somete la arquitectura a pruebas de estrés o concurrencia masiva simultánea. |
| **Latencia registrada en red local (localhost)** | Se reporta la latencia únicamente como métrica comparativa interna de sobrecarga de procesamiento, no como compromiso de nivel de servicio (SLA). | Los tiempos de respuesta no representan las condiciones reales de internet / enlace dedicado con BUSA. |

---

## 5. Declaración Formal de Alcance

> **Alcance de la evidencia técnica obtenida:**  
> La idempotencia de la operación y de la compensación ha sido **verificada empíricamente en una instancia de proceso** sobre un doble neutro. La garantía en despliegues distribuidos multi-instancia depende de la imposición del índice único en base de datos (**Dc10**) y de la atomicidad de inserción de la llave lógica `(TRAMITE_SECUENCIAL, T_PAR_SIMPLE_TRAMITE_FK)`. Por tanto, **no se afirma que la idempotencia distribuida esté demostrada empíricamente en este ciclo sumativo**, sino que queda demostrada la validez del mecanismo causal del método bajo condiciones controladas de aislamiento.
