# Diseño del ciclo sumativo

## 1. Versión evaluada

| Campo | Valor |
|:--|:--|
| Versión congelada | `ec9b8b6…` |
| ¿Se modifica durante el ciclo? | **No** |
| Doble | el mismo doble **neutro** del ciclo formativo |
| Entorno | aislado, datos sintéticos, sin BUSA real |

Si el artefacto cambia, el ciclo se invalida: hay que volver a congelar y repetir.

## 2. Comparación que demuestra el aporte

**Método vs. conducta actual**, sobre los **mismos escenarios** y el **mismo doble neutro**.

> **Advertencia metodológica.** La línea base de E6 se midió sobre un doble **idempotente por construcción**, no sobre el doble neutro. Para que la comparación sea válida, hay que **re-ejecutar la conducta actual sobre el doble neutro** (o declarar explícitamente la diferencia y su efecto). Si no, la comparación no aísla el aporte del método.

| Condición | Qué se ejecuta | Qué se mide |
|:--|:--|:--|
| **Método** | artefacto congelado (K1–K9) | duplicados, inconsistencias, invariancia, aplicabilidad |
| **Línea base** | conducta actual (reintentos con espera fija, sin verificación) | los mismos observables |

## 3. Muestra

- **2–3 practicantes independientes** (no el autor).
- **Casos distintos** por participante (no todos el 3147).
- Si es posible, **uno externo** a la organización.
- Los evaluadores del walkthrough (Leonel, Anahi) **pueden participar**, pero no como únicos y no con el mismo caso.

## 4. Diseño

- **Unidad de análisis:** escenario × participante.
- **Orden aleatorizado** de escenarios por participante (controla aprendizaje).
- **Observador independiente**: registra decisiones, errores, tiempos y ayudas. El autor **no** observa su propio método.
- **Control negativo en cada corrida:** sin K5 debe duplicar; con K5, no.

## 5. Instrumentos

- Guion por escenario con criterio de éxito (`02_guion_escenarios.md`).
- Hoja de observación (`03_hoja_observacion.md`).
- Telemetría del artefacto y contadores del doble.
- Cuestionario posterior (`04_cuestionario_posterior.md`).
- Entrevista breve (`05_entrevista_breve.md`).

## 6. Métricas

**Utilidad:** compensaciones duplicadas; operaciones inconsistentes; invariancia del estado final.
**Aplicabilidad:** tareas sin ayuda; puntos críticos a la primera; tiempo; ambigüedades.
**Eficiencia (opcional):** llamadas externas por operación; latencia.

## 7. Análisis

- Tabla por escenario y por participante, con **conteos exactos**.
- **Generalización analítica, no estadística:** con n pequeño no se estiman tasas poblacionales; se documentan mecanismos y condiciones.
- Reportar la **dirección del efecto** y los casos donde el método no mejora.

## 8. Congelación

| Campo | Valor |
|:--|:--|
| SHA-256 | `ec9b8b6…` |
| Fecha de congelación | |
| Responsable | |
| ¿Cambió durante el ciclo? | No |
